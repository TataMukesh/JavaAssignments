package Infinite.LibraryServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Return
 */
public class Return extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Return() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		HttpSession session=request.getSession();
		String uname=(String) session.getAttribute("Username");
		PrintWriter out=response.getWriter();
		RequestDispatcher rd1=request.getRequestDispatcher("/UserAccount");
		rd1.include(request, response);
		
		try {
			Connection conn=ConnectionHelper.getConnection();
			String cmd=" SELECT * FROM TranBook WHERE Username = ? " ;
			PreparedStatement pst=conn.prepareStatement(cmd);
			pst.setString(1, uname);
			ResultSet rst=pst.executeQuery();
			
			if(rst.next()) {
				out.write("<br/><br/>Select which book you want to return :");
				rst.previous();				
				out.write(
				"<form action='ReturnNext'><table><tr>"+
				"<td>BookId</td><td>Fromdate</td><td>Select</td></tr>");	
				
				while(rst.next()) {
					int bookid = rst.getInt("BookId");	
					Date fromdate = rst.getDate("Fromdate");
									
					out.write("<td>"+bookid+"</td><td>"+fromdate+"</td>" +
					"<td><input type='checkbox' name='bookid' value="+bookid+"></td></tr>");		
				}
				out.write("</table><br/><input type='submit' value='Return Books' ></form>");		
			}else {
				out.write("<br/><br /><h2>No Books to return</h2>");
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
