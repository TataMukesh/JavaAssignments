package Infinite.LibraryServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ReturnNext
 */
public class ReturnNext extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReturnNext() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	  response.setContentType("text/html");
	  HttpSession session=request.getSession();
	  String uname=(String) session.getAttribute("Username");
	  PrintWriter out=response.getWriter();
	  RequestDispatcher rd=request.getRequestDispatcher("/UserAccount");
	  rd.include(request, response);
	  Date todate = new Date(session.getLastAccessedTime());
	 
	  if(request.getParameterValues("bookid") != null) {
		  Connection conn;
		try {
			conn = ConnectionHelper.getConnection();
			 String[] ids=request.getParameterValues("bookid");
			  for (String id : ids) {
				  String cmd = "SELECT * FROM TranBook WHERE Username = ? and BookId=? ";
				  PreparedStatement pst=conn.prepareStatement(cmd);
				  pst.setString(1, uname);
				  pst.setString(2, id);
				  
				  ResultSet rst=pst.executeQuery();
				  rst.next();
				  
				  String cmd2 = " INSERT INTO TransReturn(UserName,BookId,FromDate,ToDate) VALUES (?,?,?,?)" ;
					PreparedStatement pst2 = conn.prepareStatement(cmd2);
					pst2.setString(1,uname);
					pst2.setString(2,id);
					pst2.setDate(3,rst.getDate("Fromdate"));
					pst2.setDate(4, todate);
					pst2.executeUpdate();
					
				String cmd3="DELETE FROM TranBook WHERE BookId = ? AND Username = ? ";
				PreparedStatement pst3=conn.prepareStatement(cmd3);
				pst3.setString(1, id);
				pst3.setString(2, uname);
				pst3.executeUpdate();
				
				String cmd4 = "UPDATE Books SET TotalBooks = TotalBooks+1 WHERE Id = ?" ;
				PreparedStatement pst4 = conn.prepareStatement(cmd4);
				pst4.setString(1, id);
				pst4.executeUpdate();
				
				out.write("<br/><br/>The book with Id ("+id+") is returned !...");	
				
		}
		}catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
			
		
		  
	  }else {
		  out.write("<br/><br/>Please select book to return ....... ");			
	  }
	 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
