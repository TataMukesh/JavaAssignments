package Infinite.LibraryServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SearchPrint
 */
public class SearchPrint extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchPrint() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	     RequestDispatcher rd1=request.getRequestDispatcher("/UserAccount");
	     rd1.include(request, response);
	     String serachtype=request.getParameter("searchtype");
	     String serachvalue=request.getParameter("searchvalue");
	     
	     PrintWriter out=response.getWriter();
	     
	     String cmd="";
	     
	     if(serachtype.equals("id")) {
	    	 cmd="Select * from books where Id=?";
	     }
	     else if(serachtype.equals("dept")) {
	    	 cmd="Select * from books where Dept=?"; 
	     }
	     else if(serachtype.equals("bookname")) {
	    	 cmd="Select * from books where Name=?"; 
	     }
	     else if(serachtype.equals("authorname")) {
	    	 cmd="Select * from books where Author=?"; 
	     }
	     else {
	    	 cmd="Select * from books where Name=? or 1=1";
	     }
	     
	     try {
			Connection conn=ConnectionHelper.getConnection();
			PreparedStatement pst=conn.prepareStatement(cmd,
					ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			pst.setString(1, serachvalue);
			ResultSet rst=pst.executeQuery();
			
			if(rst.next()) {
				
				out.write("<br/>Select books to issue : <br/>");
				rst.previous();				
			out.write("<html><head><meta http-equiv='Content-Type'" +
			" content='text/html; charset=ISO-8859-1'></head>"+
			"<body><form action='Issue'><table><tr>"+
			"<td>Id</td><td>Name</td><td>Author</td><td>Edition</td>" +
			"<td>Dept</td><td>TotalBooks</td><td>Select</td></tr>");
				
			while(rst.next()) 
			{					
				int bid = rst.getInt("Id");						
				String bname = rst.getString("Name");
				String bauthor = rst.getString("Author");
				String bedition = rst.getString("Edition");
				String bdept = rst.getString("Dept");	
			//	String bprice = rs.getString("Price");
				String btotal = rst.getString("TotalBooks");	
				
				out.write("<td>"+bid+"</td><td>"+bname+"</td><td>"+bauthor+"</td>" +
				"<td>"+bedition+"</td><td>"+bdept+"</td><td>"+btotal+"</td>");
				
				if(Integer.parseInt(btotal) > 0)
					out.write("<td><input type='checkbox' name='bookid' value="+bid+"></td></tr>");		
				else
					out.write("<td><input type='checkbox' name='bookid' disabled='true' value="+bid+"></td></tr>");
			}
			out.write("</table><br/><input type='submit' value='Issue Books' ></form></body></html>");	
			
			
			}
			else {
				out.write("<html><head><meta http-equiv='Content-Type'" +
						" content='text/html; charset=ISO-8859-1'></head>" +
						"<body><form action='Search'>" +
						"Sorry !... <br/> No book found for the Search Criteria<br/><br/>" +
						"<input type='submit' value='Return'></form></body></html>");
			}
			
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
