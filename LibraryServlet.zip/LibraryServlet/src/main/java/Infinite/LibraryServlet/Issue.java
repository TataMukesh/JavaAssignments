package Infinite.LibraryServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.cj.protocol.Resultset;

/**
 * Servlet implementation class Issue
 */
public class Issue extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Issue() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();
		String uname=(String) session.getAttribute("Username");
		RequestDispatcher rd1=request.getRequestDispatcher("/UserAccount");
		rd1.include(request, response);
		
		if(request.getParameterValues("bookid") != null) {
String ids[]=request.getParameterValues("bookid");
			
			try {
				Connection conn=ConnectionHelper.getConnection();
				for (String id : ids) {
					String cmd="SELECT Username FROM TranBook WHERE BookId = ? ";
				    PreparedStatement pst=conn.prepareStatement(cmd);
				    pst.setString(1, id);
				    ResultSet rst=pst.executeQuery();
				    String username=null;
				    
				    if(rst.next()) {
				    	username=rst.getString("Username");
				    }
				    
				    if(uname.equals(username)) {
				    	out.write("<br/><br/>You have already issued the book with Id ("+id+")");
				    }
				    else {
				    	String cmd1 = "INSERT INTO tranbook(userName,BookId,FromDate) VALUES(?,?,?)" ;
				    	PreparedStatement pst1=conn.prepareStatement(cmd1);
				    	pst1.setString(1, uname);
				    	pst1.setString(2, id);
				    	pst1.setDate(3, new Date(session.getLastAccessedTime()));
				    	pst1.executeUpdate();
				    	
				    	String cmd2 = "UPDATE Books SET TotalBooks = TotalBooks-1  WHERE Id = ?" ;
						PreparedStatement pst2 = conn.prepareStatement(cmd2);
						pst2.setString(1, id);
						pst2.executeUpdate();
				    	
						out.write("<br/><br/>The book with Id ("+id+") is issued !...");	
				    }
				    
					
				}
				
				
				
				
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		else {
			out.write("<br/><br/>Please select book to issue ....... ");	
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
