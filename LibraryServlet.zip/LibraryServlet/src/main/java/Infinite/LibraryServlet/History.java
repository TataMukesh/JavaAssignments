package Infinite.LibraryServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class History
 */
public class History extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public History() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		  HttpSession session=request.getSession();
		  String uname=(String) session.getAttribute("Username");
		  PrintWriter out=response.getWriter();
		  RequestDispatcher rd=request.getRequestDispatcher("/UserAccount");
		  rd.include(request, response);
		  out.write("<br/>History : <br/>");
		  
		  try {
			Connection conn=ConnectionHelper.getConnection();
			String cmd= " SELECT * FROM TransReturn WHERE Username = ? " ;	
			PreparedStatement pst=conn.prepareStatement(cmd);
			pst.setString(1, uname);
			ResultSet rst=pst.executeQuery();
			
			if(rst.next()) {
				
				rst.previous();
				out.write("<table><tr><td>BookId</td><td>Fromdate</td><td>Todate</td>"
						+ "</tr>");			
						while(rst.next()) 
						{					
							int bookid = rst.getInt("BookId");	
							Date fromdate = rst.getDate("Fromdate");
							Date todate = rst.getDate("Todate");								
							out.write("<td>"+bookid+"</td><td>"+fromdate+"</td><td>"+todate+"</td></tr>");		
						}				
						out.write("</table>");	
				
			}
			
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

}
