package com.java.complient;

import java.sql.Date;

public class Complient {
	private String complientid;
	private String complienttype;
	private String cdescription;
	private Date cdate;
	private String  severity;
	private String status;
	private int days;
	public int getDays() {
		return days;
	}
	public void setDays(int days) {
		this.days = days;
	}
	public Complient() {
		
	}
	public String getComplientid() {
		return complientid;
	}
	public void setComplientid(String complientid) {
		this.complientid = complientid;
	}
	public String getComplienttype() {
		return complienttype;
	}
	public void setComplienttype(String complienttype) {
		this.complienttype = complienttype;
	}
	public String getCdescription() {
		return cdescription;
	}
	public void setCdescription(String cdescription) {
		this.cdescription = cdescription;
	}
	public Date getCdate() {
		return cdate;
	}
	public void setCdate(Date cdate) {
		this.cdate = cdate;
	}
	public String getSeverity() {
		return severity;
	}
	public void setSeverity(String severity) {
		this.severity = severity;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	

}
