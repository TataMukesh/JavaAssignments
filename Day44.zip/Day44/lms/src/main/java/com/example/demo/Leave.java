package com.example.demo;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="leave_history")
public class Leave {

	@Id
	private int leaveId;
	private int leaveNoofdays;
	private String managerComments;
	private int empId;
	private Date leaveStartdate;
	private Date leaveEnddate;
	@Enumerated(EnumType.STRING)
	private LeaveStatus leaveStatus;
	@Enumerated(EnumType.STRING)
	private LeaveType leaveType;
	private String leaveReason;
	public int getLeaveId() {
		return leaveId;
	}
	public void setLeaveId(int leaveId) {
		this.leaveId = leaveId;
	}
	public int getLeaveNoofdays() {
		return leaveNoofdays;
	}
	public void setLeaveNoofdays(int leaveNoofdays) {
		this.leaveNoofdays = leaveNoofdays;
	}
	public String getManagerComments() {
		return managerComments;
	}
	public void setManagerComments(String managerComments) {
		this.managerComments = managerComments;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public Date getLeaveStartdate() {
		return leaveStartdate;
	}
	public void setLeaveStartdate(Date leaveStartdate) {
		this.leaveStartdate = leaveStartdate;
	}
	public Date getLeaveEnddate() {
		return leaveEnddate;
	}
	public void setLeaveEnddate(Date leaveEnddate) {
		this.leaveEnddate = leaveEnddate;
	}
	public LeaveStatus getLeaveStatus() {
		return leaveStatus;
	}
	public void setLeaveStatus(LeaveStatus leaveStatus) {
		this.leaveStatus = leaveStatus;
	}
	public LeaveType getLeaveType() {
		return leaveType;
	}
	public void setLeaveType(LeaveType leaveType) {
		this.leaveType = leaveType;
	}
	public String getLeaveReason() {
		return leaveReason;
	}
	public void setLeaveReason(String leaveReason) {
		this.leaveReason = leaveReason;
	}
	public Leave(int leaveId, int leaveNoofdays, String managerComments, int empId, Date leaveStartdate,
			Date leaveEnddate, LeaveStatus leaveStatus, LeaveType leaveType, String leaveReason) {
		this.leaveId = leaveId;
		this.leaveNoofdays = leaveNoofdays;
		this.managerComments = managerComments;
		this.empId = empId;
		this.leaveStartdate = leaveStartdate;
		this.leaveEnddate = leaveEnddate;
		this.leaveStatus = leaveStatus;
		this.leaveType = leaveType;
		this.leaveReason = leaveReason;
	}
	public Leave() {
		
	}

	
}
