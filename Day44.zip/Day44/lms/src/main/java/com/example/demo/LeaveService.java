package com.example.demo;

import java.sql.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class LeaveService {
	
	@Autowired
    private LeaveRepository repo;
	
	@Autowired
	private LeaveDao dao;
	
	public Leave search(int leaveId) {
		return repo.findById(leaveId).get();
	}
	public List<Leave> showLeaves() {
		return repo.findAll();
	}
	public List<Leave> ShowHistory(int id) {
		return dao.ShowHistory(id);
	}
	public List<Leave> ShowPendingLeaves(int id) {
		return dao.ShowPendingLeaves(id);
	}
	public String ApproveDeny(int id, int mgrid, String cmnts, String status) {
		return dao.ApproveDeny(id, mgrid, cmnts, status);
	}
	public String Addleave(int days, int empid, Date start, Date end, String reason) {
		return dao.Addleave(days, empid, start, end, reason);
	}
}
