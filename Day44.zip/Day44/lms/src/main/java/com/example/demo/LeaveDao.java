package com.example.demo;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class LeaveDao {

	@Autowired 
    JdbcTemplate jdbc;  
	
	@Autowired
	private LeaveService service;
	
	@Autowired
	private EmployService eservice;
	
	public List<Leave> ShowHistory(int id) {
		String cmd = "select * from leave_history where emp_id=?";
		List<Leave> leavesList=null;
		leavesList=jdbc.query(cmd,new Object[] {id}, new RowMapper<Leave>() {

			@Override
			public Leave mapRow(ResultSet rs, int rowNum) throws SQLException {
				Leave leaves = new Leave();
				leaves.setLeaveId(rs.getInt("LEAVE_ID"));
				leaves.setLeaveNoofdays(rs.getInt("LEAVE_NOOFDAYS"));
				leaves.setManagerComments(rs.getString("MANAGER_COMMENTS"));
				leaves.setEmpId(rs.getInt("EMP_ID"));
				leaves.setLeaveStartdate(rs.getDate("LEAVE_STARTDATE"));
				leaves.setLeaveEnddate(rs.getDate("LEAVE_ENDDATE"));
				leaves.setLeaveType(LeaveType.valueOf(rs.getString("LEAVE_TYPE")));
				leaves.setLeaveStatus(LeaveStatus.valueOf(rs.getString("LEAVE_STATUS")));
				leaves.setLeaveReason(rs.getString("LEAVE_REASON"));
				return leaves;
			}
			
		});
		return leavesList;

	}

	public List<Leave> ShowPendingLeaves(int id) {
		String cmd = "select * from leave_history where LEAVE_STATUS='PENDING' AND emp_id=?";
		List<Leave> leavesList=null;
		leavesList=jdbc.query(cmd,new Object[] {id}, new RowMapper<Leave>() {
			@Override
			public Leave mapRow(ResultSet rs, int rowNum) throws SQLException {
				Leave leaves = new Leave();
				leaves.setLeaveId(rs.getInt("LEAVE_ID"));
				leaves.setLeaveNoofdays(rs.getInt("LEAVE_NOOFDAYS"));
				leaves.setManagerComments(rs.getString("MANAGER_COMMENTS"));
				leaves.setEmpId(rs.getInt("EMP_ID"));
				leaves.setLeaveStartdate(rs.getDate("LEAVE_STARTDATE"));
				leaves.setLeaveEnddate(rs.getDate("LEAVE_ENDDATE"));
				leaves.setLeaveType(LeaveType.valueOf(rs.getString("LEAVE_TYPE")));
				leaves.setLeaveStatus(LeaveStatus.valueOf(rs.getString("LEAVE_STATUS")));
				leaves.setLeaveReason(rs.getString("LEAVE_REASON"));
				return leaves;
			}
			
		});
		return leavesList;
	}
	
	public String ApproveDeny(int id, int mgrid, String cmnts, String status) {
		Leave leave = service.search(id);
		if(leave != null) {
			int empid = leave.getEmpId();
			Employ emp = eservice.search(empid);
			int days = leave.getLeaveNoofdays();
			
			if(mgrid == emp.getMgrId()) {
				if (status.toUpperCase().equals("YES")) {
					String cmd = "Update leave_history SET LEAVE_STATUS='APPROVED', "
							+ "MANAGER_COMMENTS='"+cmnts+"' where LEAVE_ID='"+id+"' ";
					
					jdbc.update(cmd);
					return "Your Leave Approved...";
				} else {
					String cmd = "Update leave_history SET LEAVE_STATUS='DENIED', "
							+ "MANAGER_COMMENTS='"+cmnts+"' where LEAVE_ID='"+id+"' ";
					
					jdbc.update(cmd);
					return "Your Leave not Approved...";
				}
				
			} else {
				return "You are UnAuthorized Manager...";
			}
		}
		return "Invalid Leave ID...";
	}
	
	public String Addleave(int days, int empid, Date start, Date end, String reason) {
		String query="insert into leave_history(LEAVE_NOOFDAYS, EMP_ID, LEAVE_STARTDATE, LEAVE_ENDDATE, LEAVE_REASON) values('"+days+"','"+empid+"','"+start+"','"+end+"','"+reason+"')";
		jdbc.update(query); 
		return "Leave Added Succesfully...";
	}

}
