package com.example.demo;

import java.sql.Date;
import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LeaveController {

	@Autowired
	private LeaveService service;
	
	@RequestMapping(value="/showLeave")
	public List<Leave> list() {
		return service.showLeaves();
	}
	
	
	@RequestMapping("/Leave/{id}")
	public ResponseEntity<Leave> get(@PathVariable int id) {
		try {
			Leave leave = service.search(id);
		return new ResponseEntity<Leave>(leave,HttpStatus.OK);
		} catch(NoSuchElementException e) {
			return new ResponseEntity<Leave>(HttpStatus.NOT_FOUND);
		}
	}
	
	@RequestMapping("/History/{id}")
	public List<Leave> history(@PathVariable int id) {
		return service.ShowHistory(id);
	}
	
	@RequestMapping("/Pending/{id}")
	public List<Leave> pending(@PathVariable int id) {
		return service.ShowPendingLeaves(id);
	}
	
	@RequestMapping("/Approvedeny/{id}/{mgrid}/{cmnts}/{status}")
	public String approvedeny(@PathVariable int id, @PathVariable int mgrid, @PathVariable String cmnts, @PathVariable String status) {
		return service.ApproveDeny(id, mgrid, cmnts, status);
	}
	
	@RequestMapping("/Addleave/{days}/{empid}/{start}/{end}/{reason}")
	public String approvedeny(@PathVariable int days, @PathVariable int empid, @PathVariable Date start, @PathVariable Date end, @PathVariable String reason) {
		return service.Addleave(days, empid, start, end, reason);
	}
}
