package com.example.demo;

public enum LeaveType {
	EL
}
