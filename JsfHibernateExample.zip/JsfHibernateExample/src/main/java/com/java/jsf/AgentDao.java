package com.java.jsf;

import java.util.List;

import javax.faces.bean.ManagedBean;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

@ManagedBean(name="agentDao")
public class AgentDao {

	SessionFactory sf;
	public Agent[] showAgent() {
		sf = SessionHelper.getConnection();
		Session s = sf.openSession();
		Query q = s.createQuery("from Agent");
		List<Agent> agentList= q.list();
		return agentList.toArray(new Agent[agentList.size()]);
	}
}

