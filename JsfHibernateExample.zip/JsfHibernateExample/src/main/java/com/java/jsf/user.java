package com.java.jsf;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import javax.faces.context.*;

@ManagedBean(name="userDao")
@Entity
@Table(name="user")
public class user {
	private String uname;
	private String password;
	
	@Id
	@Column(name="uname")
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	
	
	@Column(name="password")
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	
	public user() {
		
	}
	
	public user(String uname, String password) {
		this.uname = uname;
		this.password = password;
	}



	SessionFactory sf;
	
	public void checkuser(){
		   try {
		      System.out.println("user name "+uname);
		      System.out.println("passowrd "+password);
		      sf = SessionHelper.getConnection();
			  Session s = sf.openSession();
			  Query q = s.createQuery("from user where uname=:username and password=:password");
		      q.setString("username", uname);
		      q.setString("password", password);
		      List list=q.list();
		      System.out.println("list size "+list.size());
		      if(list.size()==1){
		    	  	FacesContext context = FacesContext.getCurrentInstance();
		    	  	context.getExternalContext().redirect("/JsfHibernateExample/EmployShow.xhtml");
		      }
		    } catch (Exception e) {
		        System.out.println(e);
		    }
		   }
		 }
