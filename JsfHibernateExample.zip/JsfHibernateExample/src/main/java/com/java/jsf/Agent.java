package com.java.jsf;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Agent")
public class Agent {
	private int agentid;
	private String name;
	private Gender gender;
	private String city;
	private double premium;
	private int maritalstatus;
	
	@Id
	@Column(name="agentid")
	public int getAgentid() {
		return agentid;
	}
	public void setAgentid(int agentid) {
		this.agentid = agentid;
	}
	
	@Column(name="name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Enumerated(EnumType.STRING)
	@Column(name="gender")
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	
	@Column(name="city")
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	@Column(name="premium")
	public double getPremium() {
		return premium;
	}
	public void setPremium(double premium) {
		this.premium = premium;
	}
	
	@Column(name="maritalstatus")
	public int getMaritalstatus() {
		return maritalstatus;
	}
	public void setMaritalstatus(int maritalstatus) {
		this.maritalstatus = maritalstatus;
	}
	public Agent(int agentid, String name, Gender gender, String city, double premium, int maritalstatus) {
		this.agentid = agentid;
		this.name = name;
		this.gender = gender;
		this.city = city;
		this.premium = premium;
		this.maritalstatus = maritalstatus;
	}
	public Agent() {
	}
	
	
	
}
