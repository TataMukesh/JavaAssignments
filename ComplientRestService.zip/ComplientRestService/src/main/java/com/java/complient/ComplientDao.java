package com.java.complient;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ComplientDao {
	
	Connection conn;
	PreparedStatement pst;
	
	public Complient[] ShowallComplients() throws ClassNotFoundException, SQLException {
		conn=ConnectionHelper.getConnection();
		String cmd="Select * from Complaint";
		List<Complient> complist=new ArrayList<Complient>();
		pst=conn.prepareStatement(cmd);
		ResultSet rst=pst.executeQuery();
		Complient com=null;
		
		while(rst.next()) {
			com = new Complient();
			com.setComplientid(rst.getString(1));
			com.setComplienttype(rst.getString(2));
			com.setCdescription(rst.getString(3));
			com.setCdate(rst.getDate(4));
			com.setSeverity(rst.getString(5));
			com.setStatus(rst.getString(6));
			complist.add(com);
		}
		
		return complist.toArray(new Complient[complist.size()]);
	}
	
	public Complient serachComplient(String cid) throws ClassNotFoundException, SQLException {
		conn=ConnectionHelper.getConnection();
		String cmd="Select * from Complaint where ComplaintID=?";
		Complient com=null;
		pst=conn.prepareStatement(cmd);
		pst.setString(1, cid);
		ResultSet rst=pst.executeQuery();
		
		if(rst.next()) {
			com=new Complient();
			com.setComplientid(rst.getString(1));
			com.setComplienttype(rst.getString(2));
			com.setCdescription(rst.getString(3));
			com.setCdate(rst.getDate(4));
			com.setSeverity(rst.getString(5));
			com.setStatus(rst.getString(6));
		}
		return com;
	}
	
	public String AddComplient(Complient comp) throws ClassNotFoundException, SQLException {
		conn=ConnectionHelper.getConnection();
		String cmd="insert into Complaint(ComplaintID,ComplaintType,CDescription,ComplaintDate,Severity) values(?,?,?,?,?)";
		pst=conn.prepareStatement(cmd);
		pst.setString(1, comp.getComplientid());
		pst.setString(2, comp.getComplienttype());
		pst.setString(3, comp.getCdescription());
		System.out.println(comp.getCdate());
		pst.setDate(4, comp.getCdate());
		pst.setString(5, comp.getSeverity());
		
		pst.executeUpdate();
		return "**********Complient Record Inserted**************";
		
	}
	
	public String resolveComplient(Resolve res) throws ClassNotFoundException, SQLException {
		conn=ConnectionHelper.getConnection();
		String cmd="insert into resolve(ComplaintID,ComplaintDate,ResolveDate,ResolvedBy,Comments) values(?,?,?,?,?)";
		pst=conn.prepareStatement(cmd);
		pst.setString(1, res.getComplientid());
		pst.setDate(2, res.getCdate());
		pst.setDate(3, res.getResolvedDate());
		pst.setString(4, res.getResolvedby());
		pst.setString(5, res.getComments());
		pst.executeUpdate();
		
		cmd="Update Complaint set Status='Resolved' where ComplaintID=?";
		pst=conn.prepareStatement(cmd);
		pst.setString(1, res.getComplientid());
		pst.executeUpdate();
		
		return "Complient Resolved ";
		
	}

}
