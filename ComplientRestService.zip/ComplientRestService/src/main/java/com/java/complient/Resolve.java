package com.java.complient;

import java.sql.Date;

public class Resolve {
	private String complientid;
	private Date cdate;
	private Date resolvedDate;
	private String resolvedby;
	private String comments;
	public Resolve() {
		// TODO Auto-generated constructor stub
	}
	public String getComplientid() {
		return complientid;
	}
	public void setComplientid(String complientid) {
		this.complientid = complientid;
	}
	public Date getCdate() {
		return cdate;
	}
	public void setCdate(Date cdate) {
		this.cdate = cdate;
	}
	public Date getResolvedDate() {
		return resolvedDate;
	}
	public void setResolvedDate(Date resolvedDate) {
		this.resolvedDate = resolvedDate;
	}
	public String getResolvedby() {
		return resolvedby;
	}
	public void setResolvedby(String resolvedby) {
		this.resolvedby = resolvedby;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	@Override
	public String toString() {
		return "Resolve [complientid=" + complientid + ", cdate=" + cdate + ", resolvedDate=" + resolvedDate
				+ ", resolvedby=" + resolvedby + ", comments=" + comments + "]";
	}
    

}
